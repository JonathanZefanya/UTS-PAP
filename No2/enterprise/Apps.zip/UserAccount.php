<?php
namespace App\Enterprise;

class UserAccount {
    /** @var mixed */
    private $username;

    /** @var mixed */
    private $passwordHash;

    /** @var mixed */
    private $lastLogin;

    public function __construct(array $data = [])
    {
        $this->username = $data['username'] ?? null;
        $this->passwordHash = $data['passwordHash'] ?? null;
        $this->lastLogin = $data['lastLogin'] ?? null;
    }

    public function getUsername()
    {
        return $this->username;
    }

    public function setUsername($value)
    {
        $this->username = $value;
    }

    public function getPasswordHash()
    {
        return $this->passwordHash;
    }

    public function setPasswordHash($value)
    {
        $this->passwordHash = $value;
    }

    public function getLastLogin()
    {
        return $this->lastLogin;
    }

    public function setLastLogin($value)
    {
        $this->lastLogin = $value;
    }

}