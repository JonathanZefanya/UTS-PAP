<?php
namespace App\Enterprise;

class Milestone {
    /** @var mixed */
    private $id;

    /** @var mixed */
    private $title;

    /** @var mixed */
    private $dueDate;

    public function __construct(array $data = [])
    {
        $this->id = $data['id'] ?? null;
        $this->title = $data['title'] ?? null;
        $this->dueDate = $data['dueDate'] ?? null;
    }

    public function getId()
    {
        return $this->id;
    }

    public function setId($value)
    {
        $this->id = $value;
    }

    public function getTitle()
    {
        return $this->title;
    }

    public function setTitle($value)
    {
        $this->title = $value;
    }

    public function getDueDate()
    {
        return $this->dueDate;
    }

    public function setDueDate($value)
    {
        $this->dueDate = $value;
    }

}