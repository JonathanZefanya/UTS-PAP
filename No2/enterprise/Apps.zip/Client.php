<?php
namespace App\Enterprise;

class Client {
    /** @var mixed */
    private $id;

    /** @var mixed */
    private $name;

    /** @var mixed */
    private $contactInfo;

    public function __construct(array $data = [])
    {
        $this->id = $data['id'] ?? null;
        $this->name = $data['name'] ?? null;
        $this->contactInfo = $data['contactInfo'] ?? null;
    }

    public function getId()
    {
        return $this->id;
    }

    public function setId($value)
    {
        $this->id = $value;
    }

    public function getName()
    {
        return $this->name;
    }

    public function setName($value)
    {
        $this->name = $value;
    }

    public function getContactInfo()
    {
        return $this->contactInfo;
    }

    public function setContactInfo($value)
    {
        $this->contactInfo = $value;
    }

}