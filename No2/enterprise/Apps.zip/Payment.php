<?php
namespace App\Enterprise;

class Payment {
    /** @var mixed */
    private $id;

    /** @var mixed */
    private $paymentDate;

    /** @var mixed */
    private $amount;

    /** @var mixed */
    private $method;

    public function __construct(array $data = [])
    {
        $this->id = $data['id'] ?? null;
        $this->paymentDate = $data['paymentDate'] ?? null;
        $this->amount = $data['amount'] ?? null;
        $this->method = $data['method'] ?? null;
    }

    public function getId()
    {
        return $this->id;
    }

    public function setId($value)
    {
        $this->id = $value;
    }

    public function getPaymentDate()
    {
        return $this->paymentDate;
    }

    public function setPaymentDate($value)
    {
        $this->paymentDate = $value;
    }

    public function getAmount()
    {
        return $this->amount;
    }

    public function setAmount($value)
    {
        $this->amount = $value;
    }

    public function getMethod()
    {
        return $this->method;
    }

    public function setMethod($value)
    {
        $this->method = $value;
    }

}