<?php
namespace App\Enterprise;

class Resource {
    /** @var mixed */
    private $id;

    /** @var mixed */
    private $type;

    /** @var mixed */
    private $name;

    /** @var mixed */
    private $spec;

    public function __construct(array $data = [])
    {
        $this->id = $data['id'] ?? null;
        $this->type = $data['type'] ?? null;
        $this->name = $data['name'] ?? null;
        $this->spec = $data['spec'] ?? null;
    }

    public function getId()
    {
        return $this->id;
    }

    public function setId($value)
    {
        $this->id = $value;
    }

    public function getType()
    {
        return $this->type;
    }

    public function setType($value)
    {
        $this->type = $value;
    }

    public function getName()
    {
        return $this->name;
    }

    public function setName($value)
    {
        $this->name = $value;
    }

    public function getSpec()
    {
        return $this->spec;
    }

    public function setSpec($value)
    {
        $this->spec = $value;
    }

}