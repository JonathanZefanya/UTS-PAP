<?php
namespace App\Enterprise;

class Order {
    /** @var mixed */
    private $id;

    /** @var mixed */
    private $orderDate;

    /** @var mixed */
    private $status;

    public function __construct(array $data = [])
    {
        $this->id = $data['id'] ?? null;
        $this->orderDate = $data['orderDate'] ?? null;
        $this->status = $data['status'] ?? null;
    }

    public function getId()
    {
        return $this->id;
    }

    public function setId($value)
    {
        $this->id = $value;
    }

    public function getOrderDate()
    {
        return $this->orderDate;
    }

    public function setOrderDate($value)
    {
        $this->orderDate = $value;
    }

    public function getStatus()
    {
        return $this->status;
    }

    public function setStatus($value)
    {
        $this->status = $value;
    }

}