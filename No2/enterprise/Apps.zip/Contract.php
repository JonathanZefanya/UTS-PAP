<?php
namespace App\Enterprise;

class Contract {
    /** @var mixed */
    private $id;

    /** @var mixed */
    private $contractNumber;

    /** @var mixed */
    private $value;

    /** @var mixed */
    private $startDate;

    /** @var mixed */
    private $endDate;

    public function __construct(array $data = [])
    {
        $this->id = $data['id'] ?? null;
        $this->contractNumber = $data['contractNumber'] ?? null;
        $this->value = $data['value'] ?? null;
        $this->startDate = $data['startDate'] ?? null;
        $this->endDate = $data['endDate'] ?? null;
    }

    public function getId()
    {
        return $this->id;
    }

    public function setId($value)
    {
        $this->id = $value;
    }

    public function getContractNumber()
    {
        return $this->contractNumber;
    }

    public function setContractNumber($value)
    {
        $this->contractNumber = $value;
    }

    public function getValue()
    {
        return $this->value;
    }

    public function setValue($value)
    {
        $this->value = $value;
    }

    public function getStartDate()
    {
        return $this->startDate;
    }

    public function setStartDate($value)
    {
        $this->startDate = $value;
    }

    public function getEndDate()
    {
        return $this->endDate;
    }

    public function setEndDate($value)
    {
        $this->endDate = $value;
    }

}