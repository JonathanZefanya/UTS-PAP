<?php
namespace App\Enterprise;

class CartItem {
    /** @var mixed */
    private $id;

    /** @var mixed */
    private $quantity;

    public function __construct(array $data = [])
    {
        $this->id = $data['id'] ?? null;
        $this->quantity = $data['quantity'] ?? null;
    }

    public function getId()
    {
        return $this->id;
    }

    public function setId($value)
    {
        $this->id = $value;
    }

    public function getQuantity()
    {
        return $this->quantity;
    }

    public function setQuantity($value)
    {
        $this->quantity = $value;
    }

}