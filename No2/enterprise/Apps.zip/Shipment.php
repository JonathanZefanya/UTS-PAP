<?php
namespace App\Enterprise;

class Shipment {
    /** @var mixed */
    private $id;

    /** @var mixed */
    private $carrier;

    /** @var mixed */
    private $trackingNumber;

    public function __construct(array $data = [])
    {
        $this->id = $data['id'] ?? null;
        $this->carrier = $data['carrier'] ?? null;
        $this->trackingNumber = $data['trackingNumber'] ?? null;
    }

    public function getId()
    {
        return $this->id;
    }

    public function setId($value)
    {
        $this->id = $value;
    }

    public function getCarrier()
    {
        return $this->carrier;
    }

    public function setCarrier($value)
    {
        $this->carrier = $value;
    }

    public function getTrackingNumber()
    {
        return $this->trackingNumber;
    }

    public function setTrackingNumber($value)
    {
        $this->trackingNumber = $value;
    }

}