<?php
namespace App\Enterprise;

class Invoice {
    /** @var mixed */
    private $id;

    /** @var mixed */
    private $number;

    /** @var mixed */
    private $amount;

    /** @var mixed */
    private $status;

    public function __construct(array $data = [])
    {
        $this->id = $data['id'] ?? null;
        $this->number = $data['number'] ?? null;
        $this->amount = $data['amount'] ?? null;
        $this->status = $data['status'] ?? null;
    }

    public function getId()
    {
        return $this->id;
    }

    public function setId($value)
    {
        $this->id = $value;
    }

    public function getNumber()
    {
        return $this->number;
    }

    public function setNumber($value)
    {
        $this->number = $value;
    }

    public function getAmount()
    {
        return $this->amount;
    }

    public function setAmount($value)
    {
        $this->amount = $value;
    }

    public function getStatus()
    {
        return $this->status;
    }

    public function setStatus($value)
    {
        $this->status = $value;
    }

}