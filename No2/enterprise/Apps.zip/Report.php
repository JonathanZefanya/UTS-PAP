<?php
namespace App\Enterprise;

class Report {
    /** @var mixed */
    private $id;

    /** @var mixed */
    private $type;

    /** @var mixed */
    private $generatedAt;

    public function __construct(array $data = [])
    {
        $this->id = $data['id'] ?? null;
        $this->type = $data['type'] ?? null;
        $this->generatedAt = $data['generatedAt'] ?? null;
    }

    public function getId()
    {
        return $this->id;
    }

    public function setId($value)
    {
        $this->id = $value;
    }

    public function getType()
    {
        return $this->type;
    }

    public function setType($value)
    {
        $this->type = $value;
    }

    public function getGeneratedAt()
    {
        return $this->generatedAt;
    }

    public function setGeneratedAt($value)
    {
        $this->generatedAt = $value;
    }

}