<?php
namespace App\Enterprise;

class OrderLine {
    /** @var mixed */
    private $id;

    /** @var mixed */
    private $quantity;

    /** @var mixed */
    private $unitPrice;

    public function __construct(array $data = [])
    {
        $this->id = $data['id'] ?? null;
        $this->quantity = $data['quantity'] ?? null;
        $this->unitPrice = $data['unitPrice'] ?? null;
    }

    public function getId()
    {
        return $this->id;
    }

    public function setId($value)
    {
        $this->id = $value;
    }

    public function getQuantity()
    {
        return $this->quantity;
    }

    public function setQuantity($value)
    {
        $this->quantity = $value;
    }

    public function getUnitPrice()
    {
        return $this->unitPrice;
    }

    public function setUnitPrice($value)
    {
        $this->unitPrice = $value;
    }

}