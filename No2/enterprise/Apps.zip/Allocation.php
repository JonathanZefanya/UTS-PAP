<?php
namespace App\Enterprise;

class Allocation {
    /** @var mixed */
    private $id;

    /** @var mixed */
    private $quantity;

    /** @var mixed */
    private $allocatedFrom;

    /** @var mixed */
    private $allocatedTo;

    public function __construct(array $data = [])
    {
        $this->id = $data['id'] ?? null;
        $this->quantity = $data['quantity'] ?? null;
        $this->allocatedFrom = $data['allocatedFrom'] ?? null;
        $this->allocatedTo = $data['allocatedTo'] ?? null;
    }

    public function getId()
    {
        return $this->id;
    }

    public function setId($value)
    {
        $this->id = $value;
    }

    public function getQuantity()
    {
        return $this->quantity;
    }

    public function setQuantity($value)
    {
        $this->quantity = $value;
    }

    public function getAllocatedFrom()
    {
        return $this->allocatedFrom;
    }

    public function setAllocatedFrom($value)
    {
        $this->allocatedFrom = $value;
    }

    public function getAllocatedTo()
    {
        return $this->allocatedTo;
    }

    public function setAllocatedTo($value)
    {
        $this->allocatedTo = $value;
    }

}