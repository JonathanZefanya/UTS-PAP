<?php
namespace App\Enterprise;

class Notification {
    /** @var mixed */
    private $id;

    /** @var mixed */
    private $message;

    /** @var mixed */
    private $sentAt;

    /** @var mixed */
    private $read;

    public function __construct(array $data = [])
    {
        $this->id = $data['id'] ?? null;
        $this->message = $data['message'] ?? null;
        $this->sentAt = $data['sentAt'] ?? null;
        $this->read = $data['read'] ?? null;
    }

    public function getId()
    {
        return $this->id;
    }

    public function setId($value)
    {
        $this->id = $value;
    }

    public function getMessage()
    {
        return $this->message;
    }

    public function setMessage($value)
    {
        $this->message = $value;
    }

    public function getSentAt()
    {
        return $this->sentAt;
    }

    public function setSentAt($value)
    {
        $this->sentAt = $value;
    }

    public function getRead()
    {
        return $this->read;
    }

    public function setRead($value)
    {
        $this->read = $value;
    }

}