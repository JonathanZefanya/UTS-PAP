<?php
namespace App\Enterprise;

class PaymentEcom {
    /** @var mixed */
    private $id;

    /** @var mixed */
    private $method;

    /** @var mixed */
    private $amount;

    public function __construct(array $data = [])
    {
        $this->id = $data['id'] ?? null;
        $this->method = $data['method'] ?? null;
        $this->amount = $data['amount'] ?? null;
    }

    public function getId()
    {
        return $this->id;
    }

    public function setId($value)
    {
        $this->id = $value;
    }

    public function getMethod()
    {
        return $this->method;
    }

    public function setMethod($value)
    {
        $this->method = $value;
    }

    public function getAmount()
    {
        return $this->amount;
    }

    public function setAmount($value)
    {
        $this->amount = $value;
    }

}