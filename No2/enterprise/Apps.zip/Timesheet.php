<?php
namespace App\Enterprise;

class Timesheet {
    /** @var mixed */
    private $id;

    /** @var mixed */
    private $date;

    /** @var mixed */
    private $hours;

    /** @var mixed */
    private $description;

    public function __construct(array $data = [])
    {
        $this->id = $data['id'] ?? null;
        $this->date = $data['date'] ?? null;
        $this->hours = $data['hours'] ?? null;
        $this->description = $data['description'] ?? null;
    }

    public function getId()
    {
        return $this->id;
    }

    public function setId($value)
    {
        $this->id = $value;
    }

    public function getDate()
    {
        return $this->date;
    }

    public function setDate($value)
    {
        $this->date = $value;
    }

    public function getHours()
    {
        return $this->hours;
    }

    public function setHours($value)
    {
        $this->hours = $value;
    }

    public function getDescription()
    {
        return $this->description;
    }

    public function setDescription($value)
    {
        $this->description = $value;
    }

}